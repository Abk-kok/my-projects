CREATE DATABASE ADB_Banking_System;
GO

USE ADB_Banking_System;
GO
-- =============================================
-- BRANCH TABLE
-- =============================================

CREATE TABLE Branch
(
    Branch_ID INT PRIMARY KEY,

    Branch_Name VARCHAR(100)
    NOT NULL UNIQUE,

    City VARCHAR(100)
    NOT NULL,

    Phone_Number VARCHAR(20)
    UNIQUE
);
GO


-- =============================================
-- EMPLOYEE TABLE
-- =============================================

CREATE TABLE Employee
(
    Employee_ID INT PRIMARY KEY,

    First_Name VARCHAR(50)
    NOT NULL,

    Last_Name VARCHAR(50)
    NOT NULL,

    Position VARCHAR(50)
    CHECK (Position IN
    (
        'Manager',
        'Teller',
        'Auditor',
        'Loan Officer'
    )),

    Phone_Number VARCHAR(20)
    UNIQUE,

    Salary DECIMAL(15,2)
    CHECK (Salary > 0),

    Branch_ID INT NOT NULL,

    FOREIGN KEY (Branch_ID)
    REFERENCES Branch(Branch_ID)
);
GO


-- =============================================
-- CUSTOMER TABLE
-- =============================================

CREATE TABLE Customer
(
    Customer_ID INT PRIMARY KEY,

    First_Name VARCHAR(50)
    NOT NULL,

    Last_Name VARCHAR(50)
    NOT NULL,

    Email VARCHAR(100)
    UNIQUE,

    Phone_Number VARCHAR(20)
    UNIQUE,

    Address VARCHAR(200),

    Branch_ID INT NOT NULL,

    FOREIGN KEY (Branch_ID)
    REFERENCES Branch(Branch_ID)
);
GO


-- =============================================
-- ACCOUNT TABLE
-- =============================================

CREATE TABLE Account
(
    Account_Number VARCHAR(20)
    PRIMARY KEY,

    Account_Type VARCHAR(20)
    CHECK (Account_Type IN ('Savings', 'Current')),

    Balance DECIMAL(15,2)
    DEFAULT 100
    CHECK (Balance >= 100),

    Status VARCHAR(20)
    DEFAULT 'Active'
    CHECK (Status IN ('Active', 'Frozen', 'Closed')),

    Customer_ID INT NOT NULL,

    Branch_ID INT NOT NULL,

    FOREIGN KEY (Customer_ID)
    REFERENCES Customer(Customer_ID),

    FOREIGN KEY (Branch_ID)
    REFERENCES Branch(Branch_ID)
);
GO


-- =============================================
-- TRANSACTIONS TABLE
-- =============================================

CREATE TABLE Transactions
(
    Transaction_ID INT
    IDENTITY(1,1)
    PRIMARY KEY,

    From_Account VARCHAR(20),

    To_Account VARCHAR(20),

    Transaction_Type VARCHAR(20)
    CHECK (Transaction_Type IN
    (
        'Deposit',
        'Withdraw',
        'Transfer'
    )),

    Amount DECIMAL(15,2)
    CHECK (Amount > 0),

    Transaction_Status VARCHAR(20)
    DEFAULT 'Completed'
    CHECK (Transaction_Status IN
    (
        'Completed',
        'Failed',
        'Pending'
    )),

    Transaction_Date DATETIME
    DEFAULT GETDATE(),

    Employee_ID INT NOT NULL,

    FOREIGN KEY (From_Account)
    REFERENCES Account(Account_Number),

    FOREIGN KEY (To_Account)
    REFERENCES Account(Account_Number),

    FOREIGN KEY (Employee_ID)
    REFERENCES Employee(Employee_ID)
);
GO


-- =============================================
-- ACCOUNT AUDIT LOG TABLE
-- =============================================

CREATE TABLE Account_Audit_Log
(
    Log_ID INT
    IDENTITY(1,1)
    PRIMARY KEY,

    Account_Number VARCHAR(20),

    Old_Balance DECIMAL(15,2),

    New_Balance DECIMAL(15,2),

    Changed_By VARCHAR(100),

    Operation_Type VARCHAR(20),

    Change_Date DATETIME
    DEFAULT GETDATE()
);
GO


-- =============================================
-- LOAN TABLE
-- =============================================

CREATE TABLE Loan
(
    Loan_ID INT
    IDENTITY(1,1)
    PRIMARY KEY,

    Customer_ID INT NOT NULL,

    Loan_Amount DECIMAL(15,2)
    NOT NULL
    CHECK (Loan_Amount > 0),

    Interest_Rate DECIMAL(5,2)
    NOT NULL
    CHECK (Interest_Rate > 0),

    Loan_Type VARCHAR(50),

    Loan_Status VARCHAR(20)
    CHECK (Loan_Status IN
    (
        'Pending',
        'Approved',
        'Rejected',
        'Paid'
    )),

    Start_Date DATE,

    End_Date DATE,

    Created_At DATETIME
    DEFAULT GETDATE(),

    Approved_By INT,

    FOREIGN KEY (Customer_ID)
    REFERENCES Customer(Customer_ID),

    FOREIGN KEY (Approved_By)
    REFERENCES Employee(Employee_ID)
);
GO


-- =============================================
-- RECOVERY LOG TABLE
-- =============================================

CREATE TABLE Recovery_Log
(
    Recovery_ID INT
    IDENTITY(1,1)
    PRIMARY KEY,

    Transaction_ID INT,

    Operation_Type VARCHAR(50),

    Table_Name VARCHAR(50),

    Old_Value VARCHAR(MAX),

    New_Value VARCHAR(MAX),

    Recovery_Time DATETIME
    DEFAULT GETDATE()
);
GO



-- ============================================
-- INSERT VALUES INTO BRANCH TABLE
-- 25 BRANCHES
-- =============================================

INSERT INTO Branch
(
    Branch_ID,
    Branch_Name,
    City,
    Phone_Number
)

VALUES

(1, 'Hawassa Main Branch', 'Hawassa', '0462201111'),
(2, 'Addis Ababa Branch', 'Addis Ababa', '0112233445'),
(3, 'Adama Branch', 'Adama', '0223344556'),
(4, 'Bahir Dar Branch', 'Bahir Dar', '0583344556'),
(5, 'Mekelle Branch', 'Mekelle', '0344455667'),
(6, 'Jimma Branch', 'Jimma', '0475566771'),
(7, 'Dire Dawa Branch', 'Dire Dawa', '0256677882'),
(8, 'Harar Branch', 'Harar', '0257788993'),
(9, 'Arba Minch Branch', 'Arba Minch', '0468899004'),
(10, 'Dessie Branch', 'Dessie', '0339900115'),
(11, 'Gondar Branch', 'Gondar', '0581011126'),
(12, 'Axum Branch', 'Axum', '0341213147'),
(13, 'Shashemene Branch', 'Shashemene', '0461314158'),
(14, 'Wolaita Sodo Branch', 'Wolaita Sodo', '0461415169'),
(15, 'Nekemte Branch', 'Nekemte', '0571516170'),
(16, 'Debre Markos Branch', 'Debre Markos', '0581617181'),
(17, 'Debre Birhan Branch', 'Debre Birhan', '0111718192'),
(18, 'Assosa Branch', 'Assosa', '0571819203'),
(19, 'Gambella Branch', 'Gambella', '0471920214'),
(20, 'Jijiga Branch', 'Jijiga', '0252021225'),
(21, 'Semera Branch', 'Semera', '0332122236'),
(22, 'Dilla Branch', 'Dilla', '0462223247'),
(23, 'Bule Hora Branch', 'Bule Hora', '0462324258'),
(24, 'Welkite Branch', 'Welkite', '0112425269'),
(25, 'Ambo Branch', 'Ambo', '0112526270');
GO


-- =============================================
-- INSERT VALUES INTO EMPLOYEE TABLE
-- =============================================
INSERT INTO Employee
(
    Employee_ID,
    First_Name,
    Last_Name,
    Position,
    Phone_Number,
    Salary,
    Branch_ID
)

VALUES

(1, 'Abel', 'Kassa', 'Manager', '0922000001', 25000, 1),
(2, 'Helen', 'Tadesse', 'Teller', '0922000002', 12000, 2),
(3, 'Samuel', 'Bekele', 'Loan Officer', '0922000003', 18000, 3),
(4, 'Martha', 'Daniel', 'Auditor', '0922000004', 20000, 4),
(5, 'Nathan', 'Girma', 'Manager', '0922000005', 25000, 5),
(6, 'Rahel', 'Tesfaye', 'Teller', '0922000006', 12000, 6),
(7, 'Biruk', 'Haile', 'Loan Officer', '0922000007', 18000, 7),
(8, 'Meron', 'Assefa', 'Auditor', '0922000008', 20000, 8),
(9, 'Dawit', 'Mekonnen', 'Manager', '0922000009', 25000, 9),
(10, 'Sara', 'Yohannes', 'Teller', '0922000010', 12000, 10),

(11, 'Henok', 'Worku', 'Loan Officer', '0922000011', 18000, 11),
(12, 'Betelhem', 'Teka', 'Auditor', '0922000012', 20000, 12),
(13, 'Yonas', 'Fikru', 'Manager', '0922000013', 25000, 13),
(14, 'Liya', 'Abebe', 'Teller', '0922000014', 12000, 14),
(15, 'Nahom', 'Solomon', 'Loan Officer', '0922000015', 18000, 15),
(16, 'Selam', 'Demissie', 'Auditor', '0922000016', 20000, 16),
(17, 'Bereket', 'Alemu', 'Manager', '0922000017', 25000, 17),
(18, 'Hanan', 'Kebede', 'Teller', '0922000018', 12000, 18),
(19, 'Mikiyas', 'Zewdu', 'Loan Officer', '0922000019', 18000, 19),
(20, 'Eden', 'Tesema', 'Auditor', '0922000020', 20000, 20),

(21, 'Robel', 'Ayalew', 'Manager', '0922000021', 25000, 21),
(22, 'Ruth', 'Belay', 'Teller', '0922000022', 12000, 22),
(23, 'Binyam', 'Nigussie', 'Loan Officer', '0922000023', 18000, 23),
(24, 'Mahi', 'Gebre', 'Auditor', '0922000024', 20000, 24),
(25, 'Kalkidan', 'Tamiru', 'Manager', '0922000025', 25000, 25),
(26, 'Eyob', 'Mengistu', 'Teller', '0922000026', 12000, 1),
(27, 'Feven', 'Chala', 'Loan Officer', '0922000027', 18000, 2),
(28, 'Abinet', 'Tesfahun', 'Auditor', '0922000028', 20000, 3),
(29, 'Hiwot', 'Birhanu', 'Manager', '0922000029', 25000, 4),
(30, 'Tewodros', 'Lemma', 'Teller', '0922000030', 12000, 5),

(31, 'Genet', 'Habte', 'Loan Officer', '0922000031', 18000, 6),
(32, 'Kenean', 'Tadesse', 'Auditor', '0922000032', 20000, 7),
(33, 'Meaza', 'Kiros', 'Manager', '0922000033', 25000, 8),
(34, 'Natnael', 'Arega', 'Teller', '0922000034', 12000, 9),
(35, 'Tsion', 'Wolde', 'Loan Officer', '0922000035', 18000, 10),
(36, 'Fitsum', 'Dereje', 'Auditor', '0922000036', 20000, 11),
(37, 'Rediet', 'Amanuel', 'Manager', '0922000037', 25000, 12),
(38, 'Yonatan', 'Kassaye', 'Teller', '0922000038', 12000, 13),
(39, 'Meklit', 'Fanta', 'Loan Officer', '0922000039', 18000, 14),
(40, 'Surafel', 'Bekalu', 'Auditor', '0922000040', 20000, 15),

(41, 'Bethlehem', 'Hailemariam', 'Manager', '0922000041', 25000, 16),
(42, 'Nardos', 'Shimelis', 'Teller', '0922000042', 12000, 17),
(43, 'Amanuel', 'Gebru', 'Loan Officer', '0922000043', 18000, 18),
(44, 'Saron', 'Mulugeta', 'Auditor', '0922000044', 20000, 19),
(45, 'Henok', 'Tesfaye', 'Manager', '0922000045', 25000, 20),
(46, 'Yared', 'Bekele', 'Teller', '0922000046', 12000, 21),
(47, 'Lulit', 'Hailu', 'Loan Officer', '0922000047', 18000, 22),
(48, 'Nahusenay', 'Kidane', 'Auditor', '0922000048', 20000, 23),
(49, 'Samrawit', 'Fisseha', 'Manager', '0922000049', 25000, 24),
(50, 'Bereket', 'Teshome', 'Teller', '0922000050', 12000, 25),

(51, 'Abraham', 'Wolde', 'Loan Officer', '0922000051', 18000, 1),
(52, 'Mimi', 'Bekele', 'Auditor', '0922000052', 20000, 2),
(53, 'Yohannes', 'Alemayehu', 'Manager', '0922000053', 25000, 3),
(54, 'Tigist', 'Negash', 'Teller', '0922000054', 12000, 4),
(55, 'Blen', 'Asrat', 'Loan Officer', '0922000055', 18000, 5),
(56, 'Nahom', 'Tarekegn', 'Auditor', '0922000056', 20000, 6),
(57, 'Mulu', 'Goshu', 'Manager', '0922000057', 25000, 7),
(58, 'Fikir', 'Belachew', 'Teller', '0922000058', 12000, 8),
(59, 'Daniel', 'Gebeyehu', 'Loan Officer', '0922000059', 18000, 9),
(60, 'Rakeb', 'Tadesse', 'Auditor', '0922000060', 20000, 10),

(61, 'Elias', 'Kebede', 'Manager', '0922000061', 25000, 11),
(62, 'Mahlet', 'Mekuria', 'Teller', '0922000062', 12000, 12),
(63, 'Roba', 'Tesema', 'Loan Officer', '0922000063', 18000, 13),
(64, 'Tinsae', 'Molla', 'Auditor', '0922000064', 20000, 14),
(65, 'Kebrom', 'Abraha', 'Manager', '0922000065', 25000, 15),
(66, 'Genna', 'Kidanu', 'Teller', '0922000066', 12000, 16),
(67, 'Melese', 'Haftu', 'Loan Officer', '0922000067', 18000, 17),
(68, 'Lemlem', 'Assefa', 'Auditor', '0922000068', 20000, 18),
(69, 'Tarekegn', 'Ayele', 'Manager', '0922000069', 25000, 19),
(70, 'Hiwot', 'Mulu', 'Teller', '0922000070', 12000, 20),

(71, 'Kiros', 'Fisseha', 'Loan Officer', '0922000071', 18000, 21),
(72, 'Meseret', 'Abay', 'Auditor', '0922000072', 20000, 22),
(73, 'Abiy', 'Yilma', 'Manager', '0922000073', 25000, 23),
(74, 'Rahel', 'Taye', 'Teller', '0922000074', 12000, 24),
(75, 'Bamlak', 'Zerihun', 'Loan Officer', '0922000075', 18000, 25),
(76, 'Mekdes', 'Belihu', 'Auditor', '0922000076', 20000, 1),
(77, 'Aschalew', 'Teka', 'Manager', '0922000077', 25000, 2),
(78, 'Roman', 'Gebremedhin', 'Teller', '0922000078', 12000, 3),
(79, 'Tesfaye', 'Berhe', 'Loan Officer', '0922000079', 18000, 4),
(80, 'Birtukan', 'Mammo', 'Auditor', '0922000080', 20000, 5),

(81, 'Alemayehu', 'Tiruneh', 'Manager', '0922000081', 25000, 6),
(82, 'Sosina', 'Haile', 'Teller', '0922000082', 12000, 7),
(83, 'Tadele', 'Kassa', 'Loan Officer', '0922000083', 18000, 8),
(84, 'Lensa', 'Gudina', 'Auditor', '0922000084', 20000, 9),
(85, 'Demeke', 'Asefa', 'Manager', '0922000085', 25000, 10),
(86, 'Martha', 'Abate', 'Teller', '0922000086', 12000, 11),
(87, 'Buzuayehu', 'Girma', 'Loan Officer', '0922000087', 18000, 12),
(88, 'Eyerusalem', 'Tesfahun', 'Auditor', '0922000088', 20000, 13),
(89, 'Getachew', 'Meles', 'Manager', '0922000089', 25000, 14),
(90, 'Selamawit', 'Abebe', 'Teller', '0922000090', 12000, 15),

(91, 'Habtamu', 'Shiferaw', 'Loan Officer', '0922000091', 18000, 16),
(92, 'Fikirte', 'Gebru', 'Auditor', '0922000092', 20000, 17),
(93, 'Tamirat', 'Alemu', 'Manager', '0922000093', 25000, 18),
(94, 'Kidist', 'Mekonnen', 'Teller', '0922000094', 12000, 19),
(95, 'Solomon', 'Tadesse', 'Loan Officer', '0922000095', 18000, 20),
(96, 'Sena', 'Belayneh', 'Auditor', '0922000096', 20000, 21),
(97, 'Bekele', 'Negussie', 'Manager', '0922000097', 25000, 22),
(98, 'Mahilet', 'Gizaw', 'Teller', '0922000098', 12000, 23),
(99, 'Yitbarek', 'Ayalew', 'Loan Officer', '0922000099', 18000, 24),
(100, 'Rediet', 'Kebede', 'Auditor', '0922000100', 20000, 25);
GO

-- =============================================
-- INSERT 1000 CUSTOMERS USING LOOP
-- =============================================

DECLARE @Counter INT = 1;

WHILE @Counter <= 1000
BEGIN

    INSERT INTO Customer
    (
        Customer_ID,
        First_Name,
        Last_Name,
        Email,
        Phone_Number,
        Address,
        Branch_ID
    )

    VALUES
    (
        1000 + @Counter,

        'Customer' + CAST(@Counter AS VARCHAR),

        'User' + CAST(@Counter AS VARCHAR),

        'customer' + CAST(@Counter AS VARCHAR) + '@gmail.com',

        '0911' + RIGHT('000000' + CAST(@Counter AS VARCHAR),6),

        'Hawassa City',

        ((@Counter - 1) % 5) + 1
    );

    SET @Counter = @Counter + 1;

END;
GO


-- =============================================
-- INSERT 1000 ACCOUNTS USING LOOP
-- =============================================

DECLARE @Counter INT = 1;

WHILE @Counter <= 1000
BEGIN

    INSERT INTO Account
    (
        Account_Number,
        Account_Type,
        Balance,
        Status,
        Customer_ID,
        Branch_ID
    )

    VALUES
    (
        'ACC-' + CAST(1000 + @Counter AS VARCHAR),

        CASE
            WHEN @Counter % 2 = 0 THEN 'Savings'
            ELSE 'Current'
        END,

        1000 + (@Counter * 100),

        'Active',

        1000 + @Counter,

        ((@Counter - 1) % 5) + 1
    );

    SET @Counter = @Counter + 1;

END;
GO


-- =============================================
-- INSERT 1000 LOANS USING LOOP
-- =============================================

DECLARE @Counter INT = 1;

WHILE @Counter <= 1000
BEGIN

    INSERT INTO Loan
    (
        Customer_ID,
        Loan_Amount,
        Interest_Rate,
        Loan_Type,
        Loan_Status,
        Start_Date,
        End_Date,
        Approved_By
    )

    VALUES
    (
        1000 + @Counter,

        5000 + (@Counter * 20),

        5.00,

        CASE
            WHEN @Counter % 2 = 0 THEN 'Home Loan'
            ELSE 'Personal Loan'
        END,

        CASE
            WHEN @Counter % 3 = 0 THEN 'Approved'
            WHEN @Counter % 3 = 1 THEN 'Pending'
            ELSE 'Paid'
        END,

        GETDATE(),

        DATEADD(YEAR, 5, GETDATE()),

        CASE
            WHEN @Counter % 3 = 0 THEN 3
            ELSE NULL
        END
    );

    SET @Counter = @Counter + 1;

END;
GO


-- =============================================
-- AUDIT TRIGGER
-- Logs balance updates automatically
-- =============================================

CREATE TRIGGER trg_AuditAccountBalance
ON Account
AFTER UPDATE
AS
BEGIN

    INSERT INTO Account_Audit_Log
    (
        Account_Number,
        Old_Balance,
        New_Balance,
        Changed_By,
        Operation_Type
    )

    SELECT
        d.Account_Number,
        d.Balance,
        i.Balance,
        SYSTEM_USER,
        'UPDATE'

    FROM deleted d
    INNER JOIN inserted i
        ON d.Account_Number = i.Account_Number

    WHERE d.Balance <> i.Balance;

END;
GO


-- =============================================
-- AUTOMATIC RECOVERY LOG TRIGGER
-- =============================================

CREATE TRIGGER trg_RecoveryLog
ON Account
AFTER UPDATE
AS
BEGIN

    INSERT INTO Recovery_Log
    (
        Transaction_ID,
        Operation_Type,
        Table_Name,
        Old_Value,
        New_Value
    )

    SELECT
        NULL ,

        'UPDATE',

        'Account',

        'Old Balance = ' +
        CAST(d.Balance AS VARCHAR(50)),

        'New Balance = ' +
        CAST(i.Balance AS VARCHAR(50))

    FROM deleted d
    INNER JOIN inserted i
        ON d.Account_Number = i.Account_Number

    WHERE d.Balance <> i.Balance;

END;
GO


-- =============================================
-- VIEW
-- Customer account information
-- =============================================

CREATE VIEW vw_CustomerAccounts
AS

SELECT
    c.Customer_ID,
    c.First_Name,
    c.Last_Name,
    a.Account_Number,
    a.Account_Type,
    a.Balance

FROM Customer c
INNER JOIN Account a
ON c.Customer_ID = a.Customer_ID;
GO


-- =============================================
-- DEPOSIT PROCEDURE
-- =============================================

CREATE PROCEDURE sp_Deposit
(
    @AccountNo VARCHAR(20),
    @Amount DECIMAL(15,2),
    @EmployeeID INT
)
AS
BEGIN

    BEGIN TRANSACTION;

    BEGIN TRY

        IF @Amount <= 0
        BEGIN
            RAISERROR
            (
                'Deposit amount must be greater than zero.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Account
            WHERE Account_Number = @AccountNo
        )
        BEGIN
            RAISERROR('Account does not exist.',16,1);

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Employee
            WHERE Employee_ID = @EmployeeID
            AND Position IN ('Manager','Teller')
        )
        BEGIN
            RAISERROR
            (
                'Only Teller or Manager can perform deposits.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        SELECT *
        FROM Account WITH (UPDLOCK, ROWLOCK)
        WHERE Account_Number = @AccountNo;

        UPDATE Account
        SET Balance = Balance + @Amount
        WHERE Account_Number = @AccountNo;

        INSERT INTO Transactions
        (
            To_Account,
            Transaction_Type,
            Amount,
            Employee_ID
        )
        VALUES
        (
            @AccountNo,
            'Deposit',
            @Amount,
            @EmployeeID
        );

        COMMIT TRANSACTION;

        PRINT 'Deposit Successful';

    END TRY

    BEGIN CATCH

        ROLLBACK TRANSACTION;

        PRINT ERROR_MESSAGE();

    END CATCH

END;
GO


-- =============================================
-- WITHDRAW PROCEDURE
-- =============================================

CREATE PROCEDURE sp_Withdraw
(
    @AccountNo VARCHAR(20),
    @Amount DECIMAL(15,2),
    @EmployeeID INT
)
AS
BEGIN

    BEGIN TRANSACTION;

    BEGIN TRY

        DECLARE @CurrentBalance DECIMAL(15,2);

        IF @Amount <= 0
        BEGIN
            RAISERROR
            (
                'Withdraw amount must be greater than zero.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Account
            WHERE Account_Number = @AccountNo
        )
        BEGIN
            RAISERROR('Account does not exist.',16,1);

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Employee
            WHERE Employee_ID = @EmployeeID
            AND Position IN ('Manager','Teller')
        )
        BEGIN
            RAISERROR
            (
                'Only Teller or Manager can perform withdrawals.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        SELECT *
        FROM Account WITH (UPDLOCK, ROWLOCK)
        WHERE Account_Number = @AccountNo;

        SELECT @CurrentBalance = Balance
        FROM Account
        WHERE Account_Number = @AccountNo;

        IF (@CurrentBalance - @Amount) < 100
        BEGIN
            RAISERROR
            (
                'Minimum balance of 100 must be maintained.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        UPDATE Account
        SET Balance = Balance - @Amount
        WHERE Account_Number = @AccountNo;

        INSERT INTO Transactions
        (
            From_Account,
            Transaction_Type,
            Amount,
            Employee_ID
        )
        VALUES
        (
            @AccountNo,
            'Withdraw',
            @Amount,
            @EmployeeID
        );

        COMMIT TRANSACTION;

        PRINT 'Withdraw Successful';

    END TRY

    BEGIN CATCH

        ROLLBACK TRANSACTION;

        PRINT ERROR_MESSAGE();

    END CATCH

END;
GO


-- =============================================
-- ADVANCED TRANSFER PROCEDURE
-- =============================================

CREATE PROCEDURE sp_AdvancedTransfer
(
    @FromAcc VARCHAR(20),
    @ToAcc VARCHAR(20),
    @Amount DECIMAL(15,2),
    @EmployeeID INT
)
AS
BEGIN

    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

    BEGIN TRANSACTION;

    BEGIN TRY

        IF @Amount <= 0
        BEGIN
            RAISERROR
            (
                'Transfer amount must be greater than zero.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF @FromAcc = @ToAcc
        BEGIN
            RAISERROR
            (
                'Cannot transfer to the same account.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Account
            WHERE Account_Number = @FromAcc
        )
        BEGIN
            RAISERROR
            (
                'Sender account does not exist.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Account
            WHERE Account_Number = @ToAcc
        )
        BEGIN
            RAISERROR
            (
                'Receiver account does not exist.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF NOT EXISTS
        (
            SELECT 1
            FROM Employee
            WHERE Employee_ID = @EmployeeID
            AND Position IN ('Manager','Teller')
        )
        BEGIN
            RAISERROR
            (
                'Only Teller or Manager can perform transfers.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        SELECT *
        FROM Account WITH (UPDLOCK, ROWLOCK)
        WHERE Account_Number = @FromAcc;

        SELECT *
        FROM Account WITH (UPDLOCK, ROWLOCK)
        WHERE Account_Number = @ToAcc;

        IF
        (
            (
                SELECT Balance
                FROM Account
                WHERE Account_Number = @FromAcc
            ) - @Amount
        ) < 100
        BEGIN
            RAISERROR
            (
                'Minimum balance of 100 must be maintained.',
                16,
                1
            );

            ROLLBACK TRANSACTION;
            RETURN;
        END

        UPDATE Account
        SET Balance = Balance - @Amount
        WHERE Account_Number = @FromAcc;

        UPDATE Account
        SET Balance = Balance + @Amount
        WHERE Account_Number = @ToAcc;

        INSERT INTO Transactions
        (
            From_Account,
            To_Account,
            Transaction_Type,
            Amount,
            Employee_ID
        )
        VALUES
        (
            @FromAcc,
            @ToAcc,
            'Transfer',
            @Amount,
            @EmployeeID
        );

        COMMIT TRANSACTION;

        PRINT 'Transfer Successful';

    END TRY

    BEGIN CATCH

        ROLLBACK TRANSACTION;

        PRINT ERROR_MESSAGE();

    END CATCH

END;
GO


-- =============================================
-- Yearly INTEREST PROCEDURE
-- =============================================

CREATE PROCEDURE sp_AddYearlyInterest
AS
BEGIN

    BEGIN TRANSACTION;

    BEGIN TRY

        UPDATE Account
        SET Balance = Balance + (Balance * 0.005)
        WHERE Account_Type = 'Savings';

        COMMIT TRANSACTION;

        PRINT 'Yearly Interest Added';

    END TRY

    BEGIN CATCH

        ROLLBACK TRANSACTION;

        PRINT ERROR_MESSAGE();

    END CATCH

END;
GO


-- =============================================
-- LOAN APPROVAL PROCEDURE
-- =============================================

CREATE PROCEDURE sp_ApproveLoan
(
    @LoanID INT,
    @EmployeeID INT
)
AS
BEGIN

    BEGIN TRY

        IF NOT EXISTS
        (
            SELECT 1
            FROM Employee
            WHERE Employee_ID = @EmployeeID
            AND Position IN ('Manager','Loan Officer')
        )
        BEGIN
            RAISERROR
            (
                'Only Manager or Loan Officer can approve loans.',
                16,
                1
            );

            RETURN;
        END

        UPDATE Loan
        SET
            Loan_Status = 'Approved',
            Approved_By = @EmployeeID
        WHERE Loan_ID = @LoanID;

        PRINT 'Loan Approved Successfully';

    END TRY

    BEGIN CATCH

        PRINT ERROR_MESSAGE();

    END CATCH

END;
GO


-- =============================================
-- CREATE ROLES
-- =============================================

CREATE ROLE ManagerRole;
CREATE ROLE TellerRole;
CREATE ROLE LoanOfficerRole;
CREATE ROLE AuditorRole;

GO
-- =============================================
-- MANAGER PERMISSIONS
-- =============================================

GRANT CONTROL ON DATABASE::ADB_Banking_System
TO ManagerRole;
GO


-- =============================================
-- TELLER PERMISSIONS
-- =============================================

GRANT EXECUTE ON sp_Deposit
TO TellerRole;

GRANT EXECUTE ON sp_Withdraw TO TellerRole;

GRANT EXECUTE ON sp_AdvancedTransfer TO TellerRole;

GRANT SELECT, UPDATE ON Account TO TellerRole;

GRANT SELECT, INSERT ON Transactions TO TellerRole;
GO


-- =============================================
-- LOAN OFFICER PERMISSIONS
-- =============================================

GRANT EXECUTE ON sp_ApproveLoan TO LoanOfficerRole;

GRANT SELECT, UPDATE ON Loan TO LoanOfficerRole;

GRANT SELECT ON Customer TO LoanOfficerRole;

GRANT SELECT ON Account TO LoanOfficerRole;
GO
-- =============================================
-- AUDITOR PERMISSIONS
-- =============================================

GRANT SELECT ON Account_Audit_Log TO AuditorRole;

GRANT SELECT ON Transactions TO AuditorRole;

GRANT SELECT ON Recovery_Log TO AuditorRole;

GRANT SELECT ON Account TO AuditorRole;
GO

-- CREATE USERS
-- =============================================

CREATE USER [ManagerUser]
FOR LOGIN [ManagerLogin];
GO

CREATE USER [TellerUser]
FOR LOGIN [TellerLogin];
GO

CREATE USER [LoanOfficerUser]
FOR LOGIN [LoanOfficerLogin];
GO

CREATE USER [AuditorUser]
FOR LOGIN [AuditorLogin];
GO


-- =============================================
-- ASSIGN USERS TO ROLES
-- =============================================

EXEC sp_addrolemember 'ManagerRole', 'ManagerUser';
EXEC sp_addrolemember 'TellerRole', 'TellerUser';
EXEC sp_addrolemember 'LoanOfficerRole', 'LoanOfficerUser';
EXEC sp_addrolemember 'AuditorRole', 'AuditorUser';

GO
-- =============================================
-- CREATE LOGINS
-- =============================================

CREATE LOGIN [ManagerLogin]
WITH PASSWORD = 'Manager@123';
GO

CREATE LOGIN [TellerLogin]
WITH PASSWORD = 'Teller@123';
GO

CREATE LOGIN [LoanOfficerLogin]
WITH PASSWORD = 'Loan@123';
GO

CREATE LOGIN [AuditorLogin]
WITH PASSWORD = 'Audit@123';
GO




-- =============================================
----For  Create view custommer  procedure we can simply  write this

SELECT * FROM vw_CustomerAccounts;


---------------------------------------------------
-- Use of sp_Deposit Procedure

-- This procedure is used to safely deposit money into a customer account.”
-----------------------------------------------------
EXEC sp_Deposit
    @AccountNo = 'ACC-1001',
    @Amount = 500,
    @EmployeeID = 2;
  -- - -------------------------------------
  -- Check Updated Balance

    SELECT
    Account_Number,
    Balance
FROM Account
WHERE Account_Number = 'ACC-1001';

  -- - -------------------------------------
  -- - -------------------------------------
--- To Show the Query which gives Error message( in Deposit Procedure )
----------------------------------------
EXEC sp_Deposit
    @AccountNo = 'ACC-1001',
    @Amount = -500,
    @EmployeeID = 4;
    --------------------
      -- - -------------------------------------
      --- Use of sp_Advanced transfer Procedure

-- This procedure is used to securely transfer money between two accounts.”.”
-----------------------------------------------------
EXEC sp_AdvancedTransfer
    @FromAcc = 'ACC-1001',
    @ToAcc = 'ACC-1002',
    @Amount = 500,
    @EmployeeID = 2;
    -----------------------------------------------------
-- You should Execute both before and after the Advanced Transfer
    -----------------------------------------------------
    SELECT
    Account_Number,
    Balance
FROM Account
WHERE Account_Number IN ('ACC-1001','ACC-1002');

-- Retrieval Query

SELECT TOP 10
    Transaction_ID,
    From_Account,
    To_Account,
    Amount,
    Transaction_Date
FROM Transactions
WHERE Transaction_Type = 'Transfer'
ORDER BY Transaction_Date DESC;



SELECT
    c.Customer_ID,
    c.First_Name,
    c.Last_Name,
    a.Account_Number,
    a.Balance,
    t.Transaction_Type,
    t.Amount
FROM Customer c
INNER JOIN Account a
    ON c.Customer_ID = a.Customer_ID
INNER JOIN Transactions t
    ON a.Account_Number = t.From_Account
WHERE a.Balance > 50000
ORDER BY a.Balance DESC;
GO




-- =============================================
-- INDEXES (OPTIMIZATION)
-- =============================================

CREATE NONCLUSTERED INDEX IX_Account_Balance
ON Account(Balance DESC);
GO

CREATE NONCLUSTERED INDEX IX_Account_Customer
ON Account(Customer_ID, Balance);
GO
-----------------------------------
--we should run this   before and after

SELECT *
FROM Account
WHERE Customer_ID = 5
AND Balance > 5000;




-- Full database backup
BACKUP DATABASE ADB_Banking_System
TO DISK = 'C:\Backup\ADB.bak';

-- Point-in-time restore
RESTORE DATABASE ADB_Banking_System
FROM DISK = 'C:\Backup\ADB.bak';






