----For  Create view custommer  procedure we can simply  write this

SELECT * FROM vw_CustomerAccounts;


---------------------------------------------------
-- Use of sp_Deposit Procedure

-- This procedure is used to safely deposit money into a customer account.”
-----------------------------------------------------
EXEC sp_Deposit
    @AccountNo = 'ACC-1001',
    @Amount = 500,
    @EmployeeID = 2;
  -- - -------------------------------------
  -- Check Updated Balance

    SELECT
    Account_Number,
    Balance
FROM Account
WHERE Account_Number = 'ACC-1001';

  -- - -------------------------------------
  -- - -------------------------------------
--- To Show the Query which gives Error message( in Deposit Procedure )
----------------------------------------
EXEC sp_Deposit
    @AccountNo = 'ACC-1001',
    @Amount = -500,
    @EmployeeID = 4;
    --------------------
      -- - -------------------------------------
      --- Use of sp_Advanced transfer Procedure

-- This procedure is used to securely transfer money between two accounts.”.”
-----------------------------------------------------
EXEC sp_AdvancedTransfer
    @FromAcc = 'ACC-1001',
    @ToAcc = 'ACC-1002',
    @Amount = 500,
    @EmployeeID = 2;
    -----------------------------------------------------
-- You should Execute both before and after the Advanced Transfer
    -----------------------------------------------------
    SELECT
    Account_Number,
    Balance
FROM Account
WHERE Account_Number IN ('ACC-1001','ACC-1002');

-- Retrieval Query

SELECT TOP 10
    Transaction_ID,
    From_Account,
    To_Account,
    Amount,
    Transaction_Date
FROM Transactions
WHERE Transaction_Type = 'Transfer'
ORDER BY Transaction_Date DESC;







SELECT
    c.Customer_ID,
    c.First_Name,
    c.Last_Name,
    a.Account_Number,
    a.Balance,
    t.Transaction_Type,
    t.Amount
FROM Customer c
INNER JOIN Account a
    ON c.Customer_ID = a.Customer_ID
INNER JOIN Transactions t
    ON a.Account_Number = t.From_Account
WHERE a.Balance > 50000
ORDER BY a.Balance DESC;
GO